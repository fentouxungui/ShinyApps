# Before build R package for CRAN

## 1. DESCRIPTION file

Remove 'Remotes' part:

```
Remotes:
    bioc::release/ComplexHeatmap,
    github::immunogenomics/presto,
    bioc::release/MAST,
    bioc::release/limma,
    bioc::release/DESeq2
# may be also need to remove Suggests part for non-CRAN packages.

# 删除：
LazyData: true
```

Hopefully add doi info to DESCRIPTION.

## 2. Remove files

Remove files bellow:

```
# 1. this file: before-submit-to-CRAN.md
# 2. CITATION.cff
# 3. README.md
# 4. LICENSE.md
# 5. 整个inst目录
# 6. 整个data目录
# 7. R/data.R
# 8. 整个tutorials目录
```

## 3. Remove About page

Remove 'About' UI page and related server codes.
comment the tab_list[["about"]] in UI.R
comment the SeuratExplorer::GenesDB and output$ExternalLinks.UI in server.R

## 4. change package version

update package version

## 5. Check and Build the package

Check and solve all errors, warnnings and notes.

Build - More- Build Source Package.



Attention： update the CRAN package each two month.
