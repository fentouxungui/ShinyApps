#' @importFrom Seurat Project
#'
NULL

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# Generics
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#' Save a Seurat object to a Loom file
#'
#' Export a Seurat object to Loom format (HDF5-based file format optimized for storing
#' annotated matrices). Loom files are compatible with the loompy Python package and
#' other tools in the bioinformatics community. This format is useful for sharing data
#' with Python-based analysis workflows or archiving analysis results.
#'
#' @param object A Seurat object to save
#' @param filename Name of file to save the object to. If not provided, defaults to
#'   \code{<ProjectName>.loom}. The .loom extension is added automatically if not present.
#' @param overwrite Logical; if \code{TRUE}, overwrite an existing file. Default is \code{FALSE}.
#' @param verbose Logical; if \code{TRUE} (default), show progress updates
#' @param ... Arguments passed to other methods
#'
#' @return \code{writeLoom}: Invisibly returns the filename of the saved file
#'
#' @details
#' The Loom format organizes data as follows:
#' \itemize{
#'   \item \code{/matrix}: Main expression matrix (features x cells)
#'   \item \code{/row_attrs}: Feature/gene-level annotations
#'   \item \code{/col_attrs}: Cell/sample-level metadata (cell names, cluster assignments, etc.)
#'   \item \code{/layers}: Additional expression layers if present
#' }
#'
#' When saving a Seurat object:
#' \itemize{
#'   \item Default assay data becomes the main matrix
#'   \item Cell metadata and feature annotations are preserved
#'   \item Dimensional reductions are stored in col_attrs
#'   \item The SEURAT_ASSAY attribute stores the assay name for roundtrip loading
#' }
#'
#' @seealso
#' \code{\link{readLoom}} to load Loom files back as Seurat objects
#' \code{\link{writeH5Seurat}} to save in h5Seurat format
#' \code{\link{scConvert}} for converting between formats
#' \href{http://linnarssonlab.org/loompy/}{Loom documentation}
#'
#' @examples
#' \dontrun{
#' library(Seurat)
#' library(scConvert)
#'
#' # Create a Seurat object (or use an existing one)
#' seurat_obj <- CreateSeuratObject(counts = pbmc_small$RNA@counts)
#'
#' # Save to Loom format
#' writeLoom(seurat_obj, filename = "my_data.loom")
#'
#' # Save with overwrite if needed
#' writeLoom(seurat_obj, filename = "my_data.loom", overwrite = TRUE)
#'
#' # Load it back
#' loaded_obj <- readLoom("my_data.loom")
#'
#' # For sharing with Python tools
#' writeLoom(seurat_obj, filename = "data_for_python.loom")
#' # Use in Python with: adata = loompy.connect("data_for_python.loom")
#' }
#'
#' @name writeLoom
#' @rdname writeLoom
#'
#' @export
#'
writeLoom <- function(object, filename, overwrite = FALSE, verbose = TRUE, ...) {
  UseMethod(generic = 'writeLoom', object = object)
}

#' @param x A Seurat object to convert
#'
#' @return \code{as.loom}: A \code{\link{loom}} object
#'
#' @name writeLoom
#' @rdname writeLoom
#'
#' @export
#'
as.loom <- function(x, ...) {
  UseMethod(generic = 'as.loom', object = x)
}

#' Write matrix data to a loom file
#'
#' @keywords internal
#' @noRd
setGeneric(
  name = 'WriteMatrix',
  def = function(x, name, lfile, transpose = TRUE, verbose = TRUE) {
    if (!inherits(x = lfile, what = 'loom')) {
      stop("'lfile' must be a loom object", call. = FALSE)
    }
    standardGeneric(f = 'WriteMatrix')
  },
  signature = c('x')
)

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# Methods
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#' @rdname writeLoom
#' @method writeLoom default
#' @export
#'
writeLoom.default <- function(
  object,
  filename,
  overwrite = FALSE,
  verbose = TRUE,
  ...
) {
  tryCatch(
    expr = object <- as.Seurat(object = object, verbose = verbose, ...),
    error = function(...) {
      stop(
        "Unable to coerce an object of class ",
        paste(class(x = object), collapse = ', '),
        " to a Seurat object",
        call. = FALSE
      )
    }
  )
  if (missing(x = filename)) {
    filename <- paste0(Project(object = object), '.loom')
  }
  return(invisible(x = writeLoom(
    object = object,
    filename = filename,
    overwrite = overwrite,
    verbose = verbose,
    ...
  )))
}

#' @rdname writeLoom
#' @method writeLoom Seurat
#' @export
#'
writeLoom.Seurat <- function(
  object,
  filename = paste0(Project(object = object), '.loom'),
  overwrite = FALSE,
  verbose = TRUE,
  ...
) {
  loom <- as.loom(
    x = object,
    filename = filename,
    overwrite = overwrite,
    verbose = verbose,
    ...
  )
  loom$close_all()
  return(invisible(x = loom$filename))
}

#' @rdname writeLoom
#' @method as.loom default
#' @export
#'
as.loom.default <- function(x, filename, overwrite = FALSE, verbose = TRUE, ...) {
  tryCatch(
    expr = x <- as.Seurat(object = x, verbose = verbose, ...),
    error = function(...) {
      stop(
        "Unable to coerce an object of class ",
        paste(class(x = x), collapse = ', '),
        " to a Seurat object",
        call. = FALSE
      )
    }
  )
  if (missing(x = filename)) {
    filename <- paste0(Project(object = x), '.loom')
  }
  return(as.loom(
    object = x,
    filename = filename,
    overwrite = overwrite,
    verbose = verbose,
    ...
  ))
}

#' @rdname writeLoom
#' @method as.loom H5File
#' @export
#'
as.loom.H5File <- function(x, ...) {
  # Validate that this is a loom file
  if (!inherits(x = x, what = 'H5File')) {
    stop("'x' must be an H5File object", call. = FALSE)
  }
  # Check for required loom structure
  if (!x$exists(name = 'matrix')) {
    stop("H5File does not contain required '/matrix' dataset", call. = FALSE)
  }
  required.groups <- c('layers', 'row_attrs', 'col_attrs')
  for (group in required.groups) {
    if (!x$exists(name = group)) {
      stop("H5File does not contain required '", group, "' group", call. = FALSE)
    }
  }
  # Wrap the H5File in a loom object
  loom.obj <- loom$new(
    filename = x$filename,
    mode = ifelse(test = x$get_file_id()$is_writeable(), yes = 'r+', no = 'r')
  )
  return(loom.obj)
}

#' @importFrom tools file_ext
#' @importFrom Seurat Assays DefaultAssay GetAssayData Reductions Embeddings Loadings Stdev
#' @importFrom methods slotNames slot
#'
#' @rdname writeLoom
#' @method as.loom Seurat
#' @export
#'
as.loom.Seurat <- function(
  x,
  filename = paste0(Project(object = x), '.loom'),
  overwrite = FALSE,
  verbose = TRUE,
  ...
) {
  if (!grepl(pattern = '^loom$', x = file_ext(x = filename))) {
    filename <- paste0(filename, '.loom')
  }
  if (file.exists(filename)) {
    if (isTRUE(x = overwrite)) {
      warning(
        "Overwriting previous file ",
        filename,
        call. = FALSE,
        immediate. = TRUE
      )
      file.remove(filename)
    } else {
      stop("Loom file at ", filename, " already exists", call. = FALSE)
    }
  }
  lfile <- loom$new(filename = filename, mode = 'w')
  AddSlots <- function(assay) {
    for (layer_name in c('counts', 'scale.data')) {
      mat <- tryCatch(
        GetAssayData(object = x, layer = layer_name, assay = assay),
        error = function(e) NULL
      )
      if (!is.null(mat) && identical(x = dim(x = mat), y = dim(x = x))) {
        if (isTRUE(x = verbose)) {
          message("Adding layer ", layer_name, " for assay ", assay)
        }
        lfile$add_layer(
          x = mat,
          name = ifelse(
            test = assay == DefaultAssay(object = x),
            yes = layer_name,
            no = paste(assay, layer_name, sep = '_')
          ),
          verbose = verbose
        )
      }
    }
    return(invisible(x = NULL))
  }
  # Add assays
  assays.write <- lapply(
    X = Assays(object = x),
    FUN = function(i) {
      return(if (identical(x = dim(x = x[[i]]), y = dim(x = x))) {
        i
      } else {
        NULL
      })
    }
  )
  assays.write <- unlist(x = Filter(f = Negate(f = is.null), x = assays.write))
  assays.write <- setdiff(x = assays.write, y = DefaultAssay(object = x))
  # Get data layer, fall back to counts if data is empty
  main_matrix <- tryCatch(
    GetAssayData(object = x, layer = 'data'),
    error = function(e) NULL
  )
  if (is.null(main_matrix) || IsMatrixEmpty(main_matrix)) {
    main_matrix <- tryCatch(
      GetAssayData(object = x, layer = 'counts'),
      error = function(e) NULL
    )
    if (verbose && !is.null(main_matrix)) {
      message("Data layer empty, using counts from ", DefaultAssay(object = x), " as /matrix")
    }
  } else {
    if (verbose) {
      message("Saving data from ", DefaultAssay(object = x), " as /matrix")
    }
  }
  if (is.null(main_matrix) || IsMatrixEmpty(main_matrix)) {
    stop("No data or counts layer found in default assay", call. = FALSE)
  }
  WriteMatrix(
    x = main_matrix,
    name = 'matrix',
    lfile = lfile,
    verbose = verbose
  )
  AddSlots(assay = DefaultAssay(object = x))
  for (assay in assays.write) {
    if (isTRUE(x = verbose)) {
      message("Adding data for ", assay)
    }
    lfile$add_layer(
      x = GetAssayData(object = x, layer = 'data', assay = assay),
      name = assay,
      verbose = verbose
    )
    AddSlots(assay = assay)
  }
  # Add dimensional reduction information
  if (length(Reductions(object = x)) > 0) {
    # Create parent reductions group first
    if (!lfile$exists('reductions')) {
      lfile$create_group(name = 'reductions')
    }
  }
  for (reduc in Reductions(object = x)) {
    tryCatch({
      if (verbose) {
        message("Adding dimensional reduction ", reduc)
      }
      reduc.obj <- x[[reduc]]
      # Create a group for this reduction
      reduc.group <- lfile$create_group(name = H5Path('reductions', reduc))
      # Save embeddings (transpose to match loom convention: components x cells)
      embeddings <- Embeddings(object = reduc.obj)
      lfile$create_dataset(
        name = H5Path('reductions', reduc, 'embeddings'),
        robj = t(x = embeddings),
        dtype = GuessDType(x = embeddings[1, 1])
      )
      # Save loadings if available
      loadings <- tryCatch(Loadings(object = reduc.obj), error = function(e) NULL)
      if (!is.null(x = loadings) && !IsMatrixEmpty(x = loadings)) {
        lfile$create_dataset(
          name = H5Path('reductions', reduc, 'loadings'),
          robj = loadings,
          dtype = GuessDType(x = loadings[1, 1])
        )
      }
      # Save standard deviation if available
      stdev <- tryCatch(Stdev(object = reduc.obj), error = function(e) NULL)
      if (!is.null(x = stdev) && length(x = stdev) > 0) {
        lfile$create_dataset(
          name = H5Path('reductions', reduc, 'stdev'),
          robj = stdev,
          dtype = GuessDType(x = stdev)
        )
      }
    }, error = function(e) {
      warning(
        "Failed to save dimensional reduction ", reduc, ": ", e$message,
        call. = FALSE,
        immediate. = TRUE
      )
    })
  }
  # Add graphs
  # Get graph names using SeuratObject::Graphs if available

  graph_names <- tryCatch({
    # Use SeuratObject::Graphs which is exported
    if (requireNamespace("SeuratObject", quietly = TRUE) &&
        exists("Graphs", where = asNamespace("SeuratObject"), mode = "function")) {
      SeuratObject::Graphs(object = x)
    } else {
      # Fall back to checking slot names
      slot_names <- slotNames(x)
      if ("graphs" %in% slot_names && length(slot(x, "graphs")) > 0) {
        names(slot(x, "graphs"))
      } else {
        character()
      }
    }
  }, error = function(e) character())

  for (graph in graph_names) {
    tryCatch({
      lfile$add_graph(x = x[[graph]], name = graph, type = 'col')
    }, error = function(e) {
      warning(paste("Could not add graph", graph), immediate. = TRUE)
    })
  }
  # Add metadata
  lfile$add_attribute(x = colnames(x = x), name = 'CellID', type = 'col')
  # Track factor columns so we can preserve their levels; the default
  # loom col_attrs encoding collapses factors to character and drops level
  # ordering. We restore the original factor on read via the sibling group
  # col_attrs/__factor_levels__/{name}. Read directly from @meta.data —
  # x[[md, drop = TRUE]] unsets the 'ordered' class attribute.
  factor_levels_cache <- list()
  meta_df <- x@meta.data
  for (md in names(x = x[[]])) {
    col_value <- meta_df[[md]]
    if (is.factor(col_value)) {
      factor_levels_cache[[md]] <- list(
        levels  = levels(col_value),
        ordered = is.ordered(col_value)
      )
    }
    lfile$add_attribute(x = col_value, name = md, type = 'col')
  }
  if (length(factor_levels_cache) > 0) {
    # Factor levels live OUTSIDE col_attrs: the Loom spec restricts
    # col_attrs children to 1-D datasets, and loompy / scanpy raise
    # AttributeError on any sub-group under col_attrs. Use a top-level
    # scConvert-specific extension namespace instead.
    tryCatch({
      ext_path <- 'scConvert_extensions/col_factor_levels'
      if (!lfile$exists('scConvert_extensions')) {
        lfile$create_group('scConvert_extensions')
      }
      if (!lfile$exists(ext_path)) {
        lfile$create_group(ext_path)
      }
      lv_root <- lfile[[ext_path]]
      for (fname in names(factor_levels_cache)) {
        fl <- factor_levels_cache[[fname]]
        if (lv_root$exists(fname)) lv_root$link_delete(fname)
        fgrp <- lv_root$create_group(fname)
        fgrp$create_dataset(name = 'levels',
                             robj = as.character(fl$levels))
        fgrp$create_dataset(name = 'ordered',
                             robj = as.integer(isTRUE(fl$ordered)))
      }
      if (verbose) {
        message("Preserved factor levels for ",
                length(factor_levels_cache), " meta.data column(s)")
      }
    }, error = function(e) {
      warning("Could not write factor levels to loom file: ",
              conditionMessage(e), call. = FALSE)
    })
  }
  # Add feature-level metadata
  lfile$add_attribute(x = rownames(x = x), name = 'Gene', type = 'row')
  # Add feature metadata from the default assay
  default.assay <- DefaultAssay(object = x)
  if (!is.null(x = default.assay) && default.assay %in% Assays(object = x)) {
    feature.meta <- x[[default.assay]][[]]
    if (ncol(x = feature.meta) > 0) {
      for (feat.md in colnames(x = feature.meta)) {
        tryCatch({
          lfile$add_attribute(
            x = feature.meta[[feat.md]],
            name = feat.md,
            type = 'row'
          )
        }, error = function(e) {
          if (verbose) {
            warning(
              "Failed to save feature metadata '", feat.md, "': ", e$message,
              call. = FALSE,
              immediate. = TRUE
            )
          }
        })
      }
    }
  }
  return(lfile)
}

#' @importFrom Matrix t
#' @importFrom hdf5r H5S
#' @importFrom methods slot
#' @importFrom utils setTxtProgressBar
#' @keywords internal
#' @noRd
setMethod(
  f = 'WriteMatrix',
  signature = c('x' = 'dgCMatrix'),
  definition = function(x, name, lfile, transpose = TRUE, verbose = TRUE) {
    if (isTRUE(x = transpose)) {
      x <- Matrix::t(x = x)
    }
    lfile$create_dataset(
      name = name,
      dtype = GuessDType(x = x[1, 1]),
      space = H5S$new(dims = dim(x = x))
    )
    MARGIN <- GetMargin(dims = lfile[[name]]$dims)
    chunk.points <- ChunkPoints(
      dsize = lfile[[name]]$dims[MARGIN],
      csize = lfile[[name]]$chunk_dims[MARGIN]
    )
    dims <- vector(mode = 'list', length = 2L)
    dims[[-MARGIN]] <- seq_len(length.out = lfile[[name]]$dims[-MARGIN])
    if (isTRUE(x = verbose)) {
      pb <- PB()
    }
    for (i in seq_len(length.out = nrow(x = chunk.points))) {
      dims[[MARGIN]] <- seq.default(
        from = chunk.points[i, 'start'],
        to = chunk.points[i, 'end']
      )
      lfile[[name]]$write(
        args = dims,
        value = as.matrix(x = x[dims[[1]], dims[[2]]])
      )
      if (isTRUE(x = verbose)) {
        setTxtProgressBar(pb = pb, value = i / nrow(x = chunk.points))
      }
    }
    if (isTRUE(x = verbose)) {
      close(con = pb)
    }
    return(invisible(x = NULL))
  }
)

#' @keywords internal
#' @noRd
setMethod(
  f = 'WriteMatrix',
  signature = c('x' = 'matrix'),
  definition = function(x, name, lfile, transpose = TRUE, verbose = TRUE) {
    if (isTRUE(x = transpose)) {
      x <- t(x = x)
    }
    lfile$create_dataset(
      name = name,
      robj = x,
      dtype = GuessDType(x = x[1, 1])
    )
    return(invisible(x = NULL))
  }
)
