#' @include zzz.R
#' @include UtilsAssayCompat.R
#' @importFrom methods setOldClass setClassUnion setGeneric setMethod slotNames
#' slot tryNew
#' @importFrom Seurat GetAssayData Key VariableFeatures Misc Embeddings Loadings
#' DefaultAssay IsGlobal Stdev JS
#'
NULL

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# Internal utility functions
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#' Write lists and other data to an HDF5 dataset
#'
#' @inheritParams WriteH5Group
#'
#' @return Invisibly returns \code{NULL}
#'
#' @keywords internal
#'
BasicWrite <- function(x, name, hgroup, verbose = TRUE) {
  if (is.data.frame(x = x)) {
    WriteH5Group(x = x, name = name, hgroup = hgroup, verbose = verbose)
  } else if (is.list(x = x)) {
    x <- PadNames(x = x)
    xgroup <- hgroup$create_group(name = name)
    for (i in seq_along(along.with = x)) {
      WriteH5Group(
        x = x[[i]],
        name = names(x = x)[i],
        hgroup = xgroup,
        verbose = verbose
      )
    }
    if (!is.null(x = names(x = x)) && length(x = names(x = x))) {
      xgroup$create_attr(
        attr_name = 'names',
        robj = intersect(x = names(x = x), y = names(x = xgroup)),
        dtype = GuessDType(x = names(x = x)[1])
      )
    }
    if (!all(class(x = x) == 'list')) {
      xgroup$create_attr(
        attr_name = 's3class',
        robj = class(x = x),
        dtype = GuessDType(x = class(x = x)[1])
      )
    }
  } else if (is.vector(x = x) && !is.null(x = names(x = x))) {
    gzip <- GetCompressionLevel()
    if (gzip > 0L && length(x) > 64L) {
      hgroup$create_dataset(
        name = paste0(name, "__names__"),
        robj = names(x = x),
        dtype = GuessDType(x = names(x = x)),
        gzip_level = gzip
      )
      hgroup$create_dataset(name = name, robj = x, dtype = GuessDType(x = x), gzip_level = gzip)
    } else {
      hgroup$create_dataset(
        name = paste0(name, "__names__"),
        robj = names(x = x),
        dtype = GuessDType(x = names(x = x))
      )
      hgroup$create_dataset(name = name, robj = x, dtype = GuessDType(x = x))
    }
  } else if (!is.null(x = x)) {
    gzip <- GetCompressionLevel()
    if (gzip > 0L && length(x) > 64L) {
      hgroup$create_dataset(name = name, robj = x, dtype = GuessDType(x = x), gzip_level = gzip)
    } else {
      hgroup$create_dataset(name = name, robj = x, dtype = GuessDType(x = x))
    }
  }
  return(invisible(x = NULL))
}

#' Write a SpatialImage object to an HDF5 dataset
#'
#' @inheritParams WriteH5Group
#'
#' @return Invisibly returns \code{NULL}
#'
#' @keywords internal
#'
ImageWrite <- function(x, name, hgroup, verbose = TRUE) {
  if (!inherits(x = x, what = 'SpatialImage')) {
    stop(
      "'ImageWrite' work only for SpatialImage-derived objects",
      call. = FALSE
    )
  }
  xgroup <- hgroup$create_group(name = name)
  # Add assay, globality, and class information
  xgroup$create_attr(
    attr_name = 'assay',
    robj = DefaultAssay(object = x),
    dtype = GuessDType(x = DefaultAssay(object = x))
  )
  xgroup$create_attr(
    attr_name = 'global',
    robj = BoolToInt(x = IsGlobal(object = x)),
    dtype = GuessDType(x = IsGlobal(object = x))
  )
  xgroup$create_attr(
    attr_name = 's4class',
    robj = GetClass(class = class(x = x)[1]),
    dtype = GuessDType(x = GetClass(class = class(x = x)[1]))
  )
  # Write out slots other than assay
  slots <- setdiff(x = slotNames(x = x), y = c('assay', 'global'))
  for (slot in slots) {
    slot_value <- tryCatch({
      slot(object = x, name = slot)
    }, error = function(e) {
      if (slot == 'key') {
        paste0(name, '_')
      } else {
        NULL
      }
    })

    if (!is.null(slot_value)) {
      WriteH5Group(
        x = slot_value,
        name = slot,
        hgroup = xgroup,
        verbose = verbose
      )
    } else if (verbose) {
      message("Skipping slot '", slot, "' for image '", name, "' (unable to access)")
    }
  }
  return(invisible(x = NULL))
}

#' Write a sparse matrix to an HDF5 dataset
#'
#' @inheritParams WriteH5Group
#'
#' @return Invisibly returns \code{NULL}
#'
#' @keywords internal
#'
SparseWrite <- function(x, name, hgroup, verbose = TRUE) {
  xgroup <- hgroup$create_group(name = name)
  gzip <- GetCompressionLevel()
  chunk_cap <- 65536L
  datasets <- c('indices' = 'i', 'indptr' = 'p', 'data' = 'x')
  for (i in seq_along(along.with = datasets)) {
    ds.i <- slot(object = x, name = datasets[i])
    ds.len <- length(ds.i)
    if (gzip > 0L && ds.len > 0L) {
      xgroup$create_dataset(
        name = names(x = datasets)[i],
        robj = ds.i,
        dtype = GuessDType(x = ds.i),
        gzip_level = gzip,
        chunk_dims = min(ds.len, chunk_cap)
      )
    } else {
      xgroup$create_dataset(
        name = names(x = datasets)[i],
        robj = ds.i,
        dtype = GuessDType(x = ds.i)
      )
    }
  }
  xgroup$create_attr(
    attr_name = 'dims',
    robj = dim(x = x),
    dtype = GuessDType(dim(x = x))
  )
  return(invisible(x = NULL))
}

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# WriteH5Group generic
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#' Write data to an HDF5 group
#'
#' Writing data to HDF5 files can be done simply with usually sensible defaults.
#' However, when wanting any semblance of control over how an R object is
#' written out, the code constructs get complicated quickly. \code{WriteH5Group}
#' provides a wrapper with sensible defaults over some of these complex code
#' constructs to provide greater control over how data are written to disk.
#' These defaults were chosen to fit best with \link{h5Seurat} files, see
#' \code{vignette("h5Seurat-spec")} for more
#' details
#'
#' @param x An object
#' @param name Name to save data as
#' @param hgroup An HDF5 file or group (\code{H5File} or \code{H5Group} objects
#' from hdf5r)
#' @param verbose Show progress updates
#'
#' @return Invisibly returns \code{NULL}
#'
#' @export
#'
#' @examples
#' \donttest{
#' # Setup an HDF5 file
#' hfile <- hdf5r::H5File$new(filename = tempfile(fileext = '.h5'), mode = 'a')
#' }
#'
setGeneric(
  name = 'WriteH5Group',
  def = function(x, name, hgroup, verbose = TRUE) {
    if (!inherits(x = hgroup, what = c('H5File', 'H5Group'))) {
      stop(
        "'hgroup' must be an HDF5 file or group object from hdf5r",
        call. = FALSE
      )
    }
    standardGeneric(f = 'WriteH5Group')
  },
  signature = c('x')
)

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# WriteH5Group definitions
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#' @importFrom SeuratObject S4ToList
#'
#' @rdname WriteH5Group
#'
setMethod(
  f = 'WriteH5Group',
  signature = c(x = 'ANY'),
  definition = function(x, name, hgroup, verbose = TRUE) {
    if (inherits(x = x, what = 'Assay5')) {
      # Handle Assay5 when S4 dispatch fails (e.g. Seurat not attached)
      return(WriteH5GroupAssay5(x = x, name = name, hgroup = hgroup, verbose = verbose))
    } else if (inherits(x = x, what = 'SpatialImage')) {
      ImageWrite(x = x, name = name, hgroup = hgroup, verbose = verbose)
    } else if (isS4(x)) {
      xgroup <- hgroup$create_group(name = name)
      classdef <- attr(x = S4ToList(object = x), which = 'classDef')
      xgroup$create_attr(
        attr_name = 's4class',
        robj = classdef,
        dtype = GuessDType(x = classdef)
      )
      for (i in slotNames(x = x)) {
        WriteH5Group(
          x = slot(object = x, name = i),
          name = i,
          hgroup = xgroup,
          verbose = verbose
        )
      }
    } else if (!is.null(x = x)) {
      BasicWrite(x = x, name = name, hgroup = hgroup)
    }
    return(invisible(x = NULL))
  }
)

#' @rdname WriteH5Group
#'
setMethod(
  f = 'WriteH5Group',
  signature = c('x' = 'array'),
  definition = BasicWrite
)

# Simplified V5 Assay5 support
WriteH5GroupAssay5 <- function(x, name, hgroup, verbose = TRUE) {
  xgroup <- hgroup$create_group(name = name)

  # Get layers (V5 compatible)
  layers <- if (inherits(x = x, what = 'Assay5')) {
    tryCatch(SeuratObject::Layers(object = x), error = function(e) .STANDARD_LAYERS)
  } else {
    .STANDARD_LAYERS
  }

  all_cells <- tryCatch(colnames(x = x), error = function(e) NULL)
  for (layer in layers) {
    dat <- tryCatch(
      GetAssayData(object = x, layer = layer),
      error = function(e) NULL
    )

    dat <- ConvertBPCellsMatrix(dat, verbose = verbose)

    if (!is.null(dat) && !IsMatrixEmpty(x = dat)) {
      if (verbose) message("Adding ", layer, " for ", name)

      feat_names <- tryCatch(SeuratObject::Features(x),
        error = function(e) tryCatch(rownames(dat), error = function(e2) rownames(x)))

      WriteV5Layer(
        h5_group = xgroup,
        layer_name = layer,
        matrix_data = dat,
        features = feat_names,
        verbose = verbose
      )
      .WriteLayerDimnames(xgroup, layer, dat, all_cells, feat_names)
    }
  }
  .WriteDefaultLayer(xgroup, x)

  # Write features - get from SeuratObject::Features or rownames
  feat_names <- tryCatch({
    SeuratObject::Features(x)
  }, error = function(e) {
    rownames(x)
  })
  if (!is.null(feat_names)) {
    WriteH5Group(x = feat_names, name = 'features', hgroup = xgroup, verbose = verbose)
  }

  # Write key
  xgroup$create_attr(
    attr_name = 'key',
    robj = Key(object = x),
    dtype = GuessDType(x = Key(object = x))
  )

  # Write out variable features
  if (length(x = VariableFeatures(object = x))) {
    if (verbose) {
      message("Adding variable features for ", name)
    }
    WriteH5Group(
      x = VariableFeatures(object = x),
      name = 'variable.features',
      hgroup = xgroup,
      verbose = verbose
    )
  } else if (verbose) {
    message("No variable features found for ", name)
  }

  # Mark as Assay5
  xgroup$create_attr(
    attr_name = 's4class',
    robj = 'SeuratObject::Assay5',
    dtype = CachedGuessDType(x = 'SeuratObject::Assay5')
  )

  return(invisible(x = NULL))
}


# Record which cells / features a layer covers when it does not span the
# whole assay (split layers such as "counts.sample1", feature-subset
# layers), plus the default layer. Stored under `layer.cells/<layer>`,
# `layer.features/<layer>` and the `default.layer` attribute so that
# AssembleAssay() can rebuild the Assay5 exactly; readers that predate these
# fields simply ignore them.
.WriteLayerDimnames <- function(xgroup, layer, dat, all_cells, all_features) {
  lc <- colnames(x = dat); lf <- rownames(x = dat)
  if (identical(layer, 'scale.data') && !is.null(lf) && !xgroup$exists('scaled.features')) {
    # same convention as the v3 Assay writer; the index requires it before
    # scale.data is considered loadable
    xgroup$create_dataset(name = 'scaled.features', robj = lf, dtype = GuessDType(x = lf))
  }
  if (!is.null(lc) && !is.null(all_cells) && !identical(lc, all_cells)) {
    if (!xgroup$exists('layer.cells')) xgroup$create_group('layer.cells')
    xgroup[['layer.cells']]$create_dataset(name = layer, robj = lc, dtype = GuessDType(x = lc))
  }
  if (!is.null(lf) && !is.null(all_features) && !identical(lf, all_features) &&
      !identical(layer, 'scale.data')) {
    if (!xgroup$exists('layer.features')) xgroup$create_group('layer.features')
    xgroup[['layer.features']]$create_dataset(name = layer, robj = lf, dtype = GuessDType(x = lf))
  }
  invisible(NULL)
}

.WriteDefaultLayer <- function(xgroup, x) {
  dl <- tryCatch(SeuratObject::DefaultLayer(object = x), error = function(e) NULL)
  if (length(dl)) {
    xgroup$create_attr(attr_name = 'default.layer', robj = dl, dtype = GuessDType(x = dl))
  }
  lo <- tryCatch(SeuratObject::Layers(object = x), error = function(e) NULL)
  if (length(lo)) {
    xgroup$create_attr(attr_name = 'layer.order', robj = lo, dtype = GuessDType(x = lo))
  }
  invisible(NULL)
}

#' @importClassesFrom Seurat Assay
#' @importClassesFrom SeuratObject Assay5
#'
#' @rdname WriteH5Group
#'
# Add explicit method for Assay5 since it doesn't inherit from Assay in S4
setMethod(
  f = 'WriteH5Group',
  signature = c('x' = 'Assay5'),
  definition = function(x, name, hgroup, verbose = TRUE) {
    return(WriteH5GroupAssay5(x = x, name = name, hgroup = hgroup, verbose = verbose))
  }
)

#' @rdname WriteH5Group
#'
setMethod(
  f = 'WriteH5Group',
  signature = c('x' = 'Assay'),
  definition = function(x, name, hgroup, verbose = TRUE) {
    # Check if this is an Assay5 object and delegate to the appropriate method
    if (inherits(x = x, what = 'Assay5')) {
      return(WriteH5GroupAssay5(x = x, name = name, hgroup = hgroup, verbose = verbose))
    }

    xgroup <- hgroup$create_group(name = name)
    # Write out expression data
    for (i in .STANDARD_LAYERS) {
      dat <- GetAssayDataCompat(object = x, layer_or_slot = i)
      dat <- ConvertBPCellsMatrix(dat, verbose = verbose)
      if (!is.null(dat) && !IsMatrixEmpty(x = dat)) {
        if (verbose) {
          message("Adding ", i, " for ", name)
        }
        WriteH5Group(x = dat, name = i, hgroup = xgroup, verbose = verbose)
      }
      # For scale.data, ensure we have the features used
      if (i == 'scale.data' && !is.null(dat) && !IsMatrixEmpty(x = dat)) {
        WriteH5Group(
          x = rownames(x = dat),
          name = 'scaled.features',
          hgroup = xgroup,
          verbose = verbose
        )
      }
    }
    # Write out feature names
    WriteH5Group(
      x = rownames(x = x),
      name = 'features',
      hgroup = xgroup,
      verbose = verbose
    )
    # Write out the key
    xgroup$create_attr(
      attr_name = 'key',
      robj = Key(object = x),
      dtype = GuessDType(x = Key(object = x))
    )
    # Write out variable features
    if (length(x = VariableFeatures(object = x))) {
      if (verbose) {
        message("Adding variable features for ", name)
      }
      WriteH5Group(
        x = VariableFeatures(object = x),
        name = 'variable.features',
        hgroup = xgroup,
        verbose = verbose
      )
    } else if (verbose) {
      message("No variable features found for ", name)
    }
    # Write out meta.features
    if (ncol(x = x[[]])) {
      if (verbose) {
        message("Adding feature-level metadata for ", name)
      }
      WriteH5Group(
        x = x[[]],
        name = 'meta.features',
        hgroup = xgroup,
        verbose = verbose
      )
    } else if (verbose) {
      message("No feature-level metadata found for ", name)
    }
    # Write out miscellaneous data
    WriteH5Group(
      x = Misc(object = x),
      name = 'misc',
      hgroup = xgroup,
      verbose = verbose
    )
    # Write out other slots for extended assay objects
    if (class(x = x)[1] != 'Assay') {
      extclass <- attr(x = SeuratObject::S4ToList(object = x), which = 'classDef')
      xgroup$create_attr(
        attr_name = 's4class',
        robj = extclass,
        dtype = GuessDType(x = extclass)
      )
      slots.extended <- setdiff(
        x = slotNames(x = x),
        y = slotNames(x = methods::getClassDef(Class = 'Assay'))
      )
      for (slot in slots.extended) {
        if (verbose) {
          message("Writing out ", slot, " for ", name)
        }
        WriteH5Group(
          x = slot(object = x, name = slot),
          name = slot,
          hgroup = xgroup,
          verbose = verbose
        )
      }
    }
    return(invisible(x = NULL))
  }
)

#' @rdname WriteH5Group
#'
#' @examples
#' \donttest{
#' # Data frames are stored as either datasets or groups, depending on the
#' # presence of factor columns
#' df <- data.frame(
#'   x = c('g1', 'g1', 'g2', 'g1', 'g2'),
#'   y = 1:5,
#'   stringsAsFactors = FALSE
#' )
#'
#' # When no factor columns are present, the data frame is written as a single
#' # HDF5 compound dataset
#' WriteH5Group(x = df, name = 'df', hgroup = hfile)
#' hfile[['df']]
#'
#' # When factors are present, the data frame is written as a group
#' # This is because h5py does not implement HDF5 Enums, so factor level
#' # information would be lost
#' df$x <- factor(x = df$x)
#' WriteH5Group(x = df, name = 'df.factor', hgroup = hfile)
#' hfile[['df.factor']]
#' }
#'
setMethod(
  f = 'WriteH5Group',
  signature = c('x' = 'data.frame'),
  definition = function(x, name, hgroup, verbose = TRUE) {
    factor.cols <- vapply(
      X = colnames(x = x),
      FUN = function(i) {
        return(is.factor(x = x[, i, drop = TRUE]))
      },
      FUN.VALUE = logical(length = 1L),
      USE.NAMES = FALSE
    )
    bool.cols <- vapply(
      X = colnames(x = x),
      FUN = function(i) {
        return(is.logical(x = x[, i, drop = TRUE]))
      },
      FUN.VALUE = logical(length = 1L),
      USE.NAMES = FALSE
    )
    if (any(factor.cols) || getOption(x = "scConvert.dtypes.dataframe_as_group", default = TRUE)) {
      xgroup <- hgroup$create_group(name = name)
      for (i in colnames(x = x)) {
        WriteH5Group(
          x = x[, i, drop = TRUE],
          name = i,
          hgroup = xgroup,
          verbose = verbose
        )
      }
      xgroup$create_attr(
        attr_name = 'colnames',
        robj = intersect(x = colnames(x = x), y = names(x = xgroup)),
        dtype = GuessDType(x = colnames(x = x))
      )
      if (any(bool.cols)) {
        xgroup$create_attr(
          attr_name = 'logicals',
          robj = intersect(x = colnames(x = x)[bool.cols], y = names(x = xgroup)),
          dtype = GuessDType(x = colnames(x = x))
        )
      }
      if (length(x = rownames(x = x))) {
        rnames <- '_index'
        xgroup$create_attr(
          attr_name = '_index',
          robj = rnames,
          dtype = GuessDType(x = rnames)
        )
        WriteH5Group(
          x = rownames(x = x),
          name = rnames,
          hgroup = xgroup,
          verbose = verbose
        )
      }
    } else {
      for (i in colnames(x = x)[bool.cols]) {
        x[[i]] <- BoolToInt(x = x[[i]])
      }
      hgroup$create_dataset(name = name, robj = x, dtype = GuessDType(x = x))
      if (any(bool.cols)) {
        hgroup[[name]]$create_attr(
          attr_name = 'logicals',
          robj = intersect(
            x = colnames(x = x)[bool.cols],
            y = hgroup[[name]]$get_type()$get_cpd_labels()
          ),
          dtype = GuessDType(x = colnames(x = x))
        )
      }
    }
    return(invisible(x = NULL))
  }
)

#' @rdname WriteH5Group
#'
setMethod(
  f = 'WriteH5Group',
  signature = c('x' = 'dgCMatrix'),
  definition = SparseWrite
)

#' @importClassesFrom Seurat DimReduc
#'
#' @rdname WriteH5Group
#'
setMethod(
  f = 'WriteH5Group',
  signature = c('x' = 'DimReduc'),
  definition = function(x, name, hgroup, verbose = TRUE) {
    xgroup <- hgroup$create_group(name = name)
    # Add cell embeddings
    if (verbose) {
      message("Adding cell embeddings for ", name)
    }
    WriteH5Group(
      x = Embeddings(object = x),
      name = 'cell.embeddings',
      hgroup = xgroup,
      verbose = verbose
    )
    # Add feature loadings
    for (i in c('feature.loadings', 'feature.loadings.projected')) {
      projected <- grepl(pattern = 'projected', x = i)
      type <- ifelse(test = projected, yes = 'projected loadings', no = 'loadings')
      if (!IsMatrixEmpty(x = Loadings(object = x, projected = projected))) {
        if (verbose) {
          message("Adding ", type, " for ", name)
        }
        loadings <- Loadings(object = x, projected = projected)
        WriteH5Group(x = loadings, name = i, hgroup = xgroup, verbose = verbose)
        WriteH5Group(
          x = rownames(x = loadings),
          name = ifelse(test = projected, yes = 'projected.features', no = 'features'),
          hgroup = xgroup,
          verbose = verbose
        )
      } else if (verbose) {
        message("No ", type, " for ", name)
      }
    }
    # Add assay, key, and global status
    xgroup$create_attr(
      attr_name = 'active.assay',
      robj = DefaultAssay(object = x),
      dtype = GuessDType(x = DefaultAssay(object = x))
    )
    xgroup$create_attr(
      attr_name = 'key',
      robj = Key(object = x),
      dtype = GuessDType(x = Key(object = x))
    )
    xgroup$create_attr(
      attr_name = 'global',
      robj = BoolToInt(x = IsGlobal(object = x)),
      dtype = GuessDType(x = IsGlobal(object = x))
    )
    # Add standard deviations
    if (length(x = Stdev(object = x)) > 0) {
      if (verbose) {
        message("Adding standard deviations for ", name)
      }
      WriteH5Group(
        x = Stdev(object = x),
        name = 'stdev',
        hgroup = xgroup,
        verbose = verbose
      )
    } else if (verbose) {
      message("No standard deviations for ", name)
    }
    # Add JackStraw
    if (as.logical(x = JS(object = x))) {
      if (verbose) {
        message("Adding JackStraw information for ", name)
      }
      WriteH5Group(
        x = JS(object = x),
        name = 'jackstraw',
        hgroup = xgroup,
        verbose = verbose
      )
    } else if (verbose) {
      message("No JackStraw data for ", name)
    }
    # Add misc
    WriteH5Group(
      x = slot(object = x, name = 'misc'),
      name = 'misc',
      hgroup = xgroup,
      verbose = verbose
    )
    return(invisible(x = NULL))
  }
)

#' @rdname WriteH5Group
#'
#' @examples
#' \donttest{
#' # Factors turn into a group with two components: values and levels
#' # This is to preserve level information for HDF5 APIs that don't implement
#' # the HDF5 Enum type (eg. h5py)
#' # values corresponds to the integer values of each member of a factor
#' # levels is a string dataset with one entry per level
#' fctr <- factor(x = c('g1', 'g1', 'g2', 'g1', 'g2'))
#' WriteH5Group(x = fctr, name = 'factor', hgroup = hfile)
#' hfile[['factor']]
#' }
#'
setMethod(
  f = 'WriteH5Group',
  signature = c('x' = 'factor'),
  definition = function(x, name, hgroup, verbose = TRUE) {
    xgroup <- hgroup$create_group(name = name)
    # Write the integer values out
    WriteH5Group(
      x = as.integer(x = x),
      name = 'values',
      hgroup = xgroup,
      verbose = verbose
    )
    # Write the levels out
    WriteH5Group(
      x = levels(x = x),
      name = 'levels',
      hgroup = xgroup,
      verbose = verbose
    )
  }
)

#' @importClassesFrom Seurat Graph
#'
#' @rdname WriteH5Group
#'
setMethod(
  f = 'WriteH5Group',
  signature = c('x' = 'Graph'),
  definition = function(x, name, hgroup, verbose = TRUE) {
    SparseWrite(x = x, name = name, hgroup = hgroup, verbose = verbose)
    if (!is.null(x = DefaultAssay(object = x))) {
      hgroup[[name]]$create_attr(
        attr_name = 'assay.used',
        robj = DefaultAssay(object = x),
        dtype = GuessDType(x = DefaultAssay(object = x))
      )
    }
    return(invisible(x = NULL))
  }
)

#' @rdname WriteH5Group
#'
setMethod(
  f = 'WriteH5Group',
  signature = c('x' = 'list'),
  definition = BasicWrite
)

#' @rdname WriteH5Group
#'
#' @examples
#' \donttest{
#' # Logicals get encoded as integers with the following mapping
#' # FALSE becomes 0L
#' # TRUE becomes 1L
#' # NA becomes 2L
#' # These are stored as H5T_INTEGERS instead of H5T_LOGICALS
#' # Additionally, an attribute called "s3class" is written with the value of "logical"
#' WriteH5Group(c(TRUE, FALSE, NA), name = "logicals", hgroup = hfile)
#' hfile[["logicals"]]
#' hfile[["logicals"]]$attr_open("s3class")$read()
#' }
#'
setMethod(
  f = 'WriteH5Group',
  signature = c('x' = 'logical'),
  definition = function(x, name, hgroup, verbose = TRUE) {
    WriteH5Group(
      x = BoolToInt(x = x),
      name = name,
      hgroup = hgroup,
      verbose = verbose
    )
    hgroup[[name]]$create_attr(
      attr_name = 's3class',
      robj = 'logical',
      dtype = CachedGuessDType(x = 'logical')
    )
    return(invisible(x = NULL))
  }
)

#' @importClassesFrom Seurat Neighbor
#'
#' @rdname WriteH5Group
#'
setMethod(
  f = 'WriteH5Group',
  signature = c('x' = 'Neighbor'),
  definition = function(x, name, hgroup, verbose = TRUE) {
    xgroup <- hgroup$create_group(name = name)
    for (i in slotNames(x = x)) {
      if (i == 'alg.idx' && !is.null(x = slot(object = x, name = i))) {
        warning(
          "We cannot save neighbor indexes at this time; ",
          "please save the index separately",
          call. = FALSE,
          immediate. = TRUE
        )
        next
      }
      WriteH5Group(
        x = slot(object = x, name = i),
        name = i,
        hgroup = xgroup,
        verbose = verbose
      )
    }
  }
)

#' @importClassesFrom Seurat SeuratCommand
#'
#' @rdname WriteH5Group
#'
setMethod(
  f = 'WriteH5Group',
  signature = c('x' = 'SeuratCommand'),
  definition = function(x, name, hgroup, verbose = TRUE) {
    # Write out params
    WriteH5Group(
      x = Filter(
        f = Negate(f = is.function),
        x = as.list(x = x)
      ),
      name = name,
      hgroup = hgroup,
      verbose = verbose
    )
    # Add extra information as HDF5 attributes
    for (slot in slotNames(x = x)) {
      if (slot == 'params') {
        next
      }
      slot.val <- slot(object = x, name = slot)
      if (!is.null(x = slot.val)) {
        slot.val <- as.character(x = slot.val)
        hgroup[[name]]$create_attr(
          attr_name = slot,
          robj = slot.val,
          dtype = GuessDType(x = slot.val)
        )
      }
    }
    return(invisible(x = NULL))
  }
)

#' @name WriteH5Group
#' @rdname WriteH5Group
#'
#' @examples
#' \donttest{
#' # Close and remove the HDF5 file
#' hfile$close_all()
#' file.remove(hfile$filename)
#' }
#'
NULL
