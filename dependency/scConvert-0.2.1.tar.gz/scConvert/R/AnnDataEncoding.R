#' @include zzz.R
#' @importFrom Matrix sparseMatrix t
NULL

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# AnnData Encoding/Decoding Helpers (Backend-Agnostic)
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#' Decode AnnData categorical encoding to R factor
#'
#' The factor levels follow the stored category order verbatim (pandas
#' preserves an explicit category order; re-sorting it alphabetically would
#' silently reorder positional palettes and any order-dependent downstream
#' logic). When the AnnData categorical carries \code{ordered = TRUE}, pass
#' it here to get an ordered factor back.
#'
#' @param codes Integer vector of 0-based category codes (-1 = NA)
#' @param categories Character vector of category labels
#' @param ordered Logical; produce an ordered factor (AnnData's
#'   \code{ordered} categorical flag). Default \code{FALSE}.
#'
#' @return A factor vector
#'
#' @keywords internal
#'
DecodeCategorical <- function(codes, categories, ordered = FALSE) {
  codes[codes == -1L] <- NA_integer_
  valid <- !is.na(codes) & codes >= 0L & codes < length(categories)
  if (!all(valid[!is.na(codes)])) {
    n_bad <- sum(!valid[!is.na(codes)])
    warning(sprintf(
      "Categorical decoding: %d code(s) out of bounds [0, %d). Setting to NA.",
      n_bad, length(categories)
    ))
    codes[!is.na(codes) & !valid] <- NA_integer_
  }
  factor(categories[codes + 1L], levels = categories, ordered = isTRUE(ordered))
}

#' Encode R factor as AnnData categorical
#'
#' @param x A factor (or coercible to factor)
#'
#' @return A list with \code{codes} (0-based integer) and \code{categories}
#'   (character vector of levels)
#'
#' @keywords internal
#'
EncodeCategorical <- function(x) {
  x <- as.factor(x)
  codes <- as.integer(x) - 1L
  codes[is.na(x)] <- -1L
  list(codes = codes, categories = levels(x))
}

#' Reconstruct sparse CSR/CSC matrix from array components
#'
#' @param data Numeric vector of non-zero values
#' @param indices Integer vector of column (CSR) or row (CSC) indices (0-based)
#' @param indptr Integer vector of row (CSR) or column (CSC) pointers
#' @param shape Integer vector of length 2: c(n_rows, n_cols)
#' @param transpose If TRUE, transpose result (h5ad stores cells x genes,
#'   Seurat needs genes x cells)
#'
#' @return A dgCMatrix
#'
#' @keywords internal
#'
ReconstructSparseCSR <- function(data, indices, indptr, shape, transpose = TRUE) {
  indices_1based <- indices + 1L
  n_rows <- shape[1]
  n_cols <- shape[2]
  row_indices <- rep(seq_len(n_rows), diff(indptr))
  mat <- sparseMatrix(
    i = row_indices,
    j = indices_1based,
    x = data,
    dims = c(n_rows, n_cols),
    index1 = TRUE
  )
  if (transpose) mat <- t(mat)
  mat
}

#' Deconstruct dgCMatrix to AnnData CSR components
#'
#' AnnData stores expression matrices as cells x genes in CSR format.
#' This function converts a genes x cells dgCMatrix to CSR components
#' for the cells x genes layout.
#'
#' @param mat A dgCMatrix (genes x cells)
#' @param coerce If TRUE (default), coerce mat to dgCMatrix first
#'
#' @return A list with \code{data}, \code{indices} (0-based), \code{indptr},
#'   and \code{shape} (cells, genes)
#'
#' @keywords internal
#'
DeconstructSparseCSR <- function(mat, coerce = TRUE) {
  if (coerce) mat <- as(mat, "dgCMatrix")
  # CSC of (genes x cells) == CSR of (cells x genes) — zero-copy reinterpretation
  # dgCMatrix @p = column pointers, @i = row indices (0-based), @x = values
  # Reinterpreted as CSR: @p = row pointers, @i = column indices, @x = values
  list(
    data = mat@x,
    indices = mat@i,       # 0-based row indices in CSC = column indices in transposed CSR
    indptr = mat@p,        # column pointers in CSC = row pointers in transposed CSR
    shape = as.integer(rev(dim(mat)))  # c(n_cells, n_genes)
  )
}

#' Map AnnData reduction name to Seurat key
#'
#' @param name Reduction name (e.g., "pca", "umap", "tsne")
#'
#' @return A Seurat-style key string (e.g., "PC_", "UMAP_")
#'
#' @keywords internal
#'
AnnDataReductionKey <- function(name) {
  switch(name,
    "pca" = "PC_",
    "tsne" = "tSNE_",
    "umap" = "UMAP_",
    "harmony" = "harmony_",
    "scvi" = "scVI_",
    paste0(toupper(name), "_")
  )
}

#' Map AnnData layer name to Seurat layer name
#'
#' @param name AnnData layer name
#'
#' @return Seurat layer name
#'
#' @keywords internal
#'
AnnDataLayerToSeurat <- function(name) {
  switch(name,
    "counts" = "counts",
    "data" = "data",
    "log_normalized" = "data",
    "scale.data" = "scale.data",
    "scaled" = "scale.data",
    name
  )
}

#' Map Seurat layer name to AnnData layer name
#'
#' @param name Seurat layer name
#'
#' @return AnnData layer name
#'
#' @keywords internal
#'
SeuratLayerToAnnData <- function(name) {
  switch(name,
    "counts" = "counts",
    "data" = "data",
    "scale.data" = "scaled",
    name
  )
}

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# Zarr v2 Low-Level I/O Helpers
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#' Detect zarr store format version
#'
#' @param store_path Path to zarr store directory
#'
#' @return 2L or 3L
#'
#' @keywords internal
#'
.zarr_store_version <- function(store_path) {
  store <- .zarr_make_store(store_path)
  if (store$exists(".zgroup") || store$exists(".zarray")) return(2L)
  if (store$exists("zarr.json")) return(3L)
  stop("Not a valid zarr store: ", store$root, call. = FALSE)
}

#' Normalise zarr v3 codecs to a list of row-like entries
#'
#' jsonlite::fromJSON(simplifyVector=TRUE) collapses an array of objects
#' into a data.frame. We need each row as a list with name and configuration
#' sub-list. Use jsonlite::fromJSON(simplifyVector=FALSE) parsing path or
#' re-parse the dataframe rows carefully preserving nested structure.
#'
#' @keywords internal
.zarr_codecs_as_list <- function(codecs) {
  if (is.null(codecs)) return(list())
  if (is.data.frame(codecs)) {
    return(lapply(seq_len(nrow(codecs)), function(i) {
      cfg_col <- codecs[["configuration"]]
      cfg <- if (is.data.frame(cfg_col)) {
        as.list(cfg_col[i, , drop = FALSE])
      } else if (is.list(cfg_col)) {
        cfg_col[[i]]
      } else {
        list()
      }
      list(name = codecs[["name"]][[i]], configuration = cfg)
    }))
  }
  if (is.list(codecs)) {
    # jsonlite may hand us a list wrapping a data.frame (e.g. the inner
    # `codecs` of a sharding configuration); flatten to one entry per codec
    out <- list()
    for (el in codecs) {
      if (is.data.frame(el)) {
        out <- c(out, .zarr_codecs_as_list(el))
      } else if (is.list(el) && !is.null(el$name) && length(el$name) == 1L) {
        out <- c(out, list(el))
      } else if (is.list(el)) {
        out <- c(out, .zarr_codecs_as_list(el))
      }
    }
    return(out)
  }
  list()
}

#' Parse zarr v3 data_type string into dtype_info struct
#'
#' @keywords internal
.zarr_parse_dtype_v3 <- function(data_type, codecs = NULL) {
  endian <- "little"
  codec_list <- .zarr_codecs_as_list(codecs)
  for (codec in codec_list) {
    if (identical(codec$name, "bytes")) {
      cfg <- codec$configuration
      if (is.data.frame(cfg)) cfg <- as.list(cfg[1, , drop = FALSE])
      endian <- cfg$endian %||% "little"
      if (is.na(endian)) endian <- "little"
      break
    }
  }
  switch(data_type,
    float64  = list(r_type = "double",    size = 8L, endian = endian, signed = TRUE,  is_object = FALSE),
    float32  = list(r_type = "double",    size = 4L, endian = endian, signed = TRUE,  is_object = FALSE),
    float16  = list(r_type = "double",    size = 2L, endian = endian, signed = TRUE,  is_object = FALSE),
    int64    = list(r_type = "integer",   size = 8L, endian = endian, signed = TRUE,  is_object = FALSE),
    int32    = list(r_type = "integer",   size = 4L, endian = endian, signed = TRUE,  is_object = FALSE),
    int16    = list(r_type = "integer",   size = 2L, endian = endian, signed = TRUE,  is_object = FALSE),
    int8     = list(r_type = "integer",   size = 1L, endian = endian, signed = TRUE,  is_object = FALSE),
    uint64   = list(r_type = "integer",   size = 8L, endian = endian, signed = FALSE, is_object = FALSE),
    uint32   = list(r_type = "integer",   size = 4L, endian = endian, signed = FALSE, is_object = FALSE),
    uint16   = list(r_type = "integer",   size = 2L, endian = endian, signed = FALSE, is_object = FALSE),
    uint8    = list(r_type = "integer",   size = 1L, endian = endian, signed = FALSE, is_object = FALSE),
    bool     = list(r_type = "logical",   size = 1L, endian = endian, signed = TRUE,  is_object = FALSE),
    string   = list(r_type = "character", size = 0L, endian = "little", signed = TRUE, is_object = TRUE),
             list(r_type = "double",    size = 8L, endian = endian, signed = TRUE,  is_object = FALSE)
  )
}

#' Extract compressor spec from zarr v3 codecs array
#'
#' @keywords internal
.zarr_extract_compressor_v3 <- function(codecs) {
  codec_list <- .zarr_codecs_as_list(codecs)
  if (length(codec_list) == 0L) return(NULL)
  skip <- c("bytes", "vlen-utf8", "transpose")
  for (codec in codec_list) {
    if (is.null(codec$name) || codec$name %in% skip) next
    cfg <- codec$configuration %||% list()
    if (is.data.frame(cfg)) cfg <- as.list(cfg[1, , drop = FALSE])
    level <- cfg$level %||% 0L
    if (!is.null(level) && !is.na(level)) level <- as.integer(level) else level <- 0L
    return(list(id = codec$name, level = level))
  }
  NULL
}

#' Read and normalise zarr array metadata (v2 and v3)
#'
#' Returns a uniform list regardless of zarr format version:
#' shape, chunks, dtype_info, compressor, fill_value, order,
#' version, chunk_prefix, chunk_sep, is_string.
#'
#' @keywords internal
.zarr_read_array_meta <- function(store, rel_path) {
  store <- .zarr_make_store(store)

  # Detect format from array-level metadata files, not store root.
  # This makes the function work even when the parent directory is not a
  # properly formed zarr store root (e.g., bare temp directories in tests).
  zarray_path <- if (nzchar(rel_path)) file.path(rel_path, ".zarray") else ".zarray"
  zjson_path  <- if (nzchar(rel_path)) file.path(rel_path, "zarr.json") else "zarr.json"

  version <- if (store$exists(zarray_path)) 2L else if (store$exists(zjson_path)) 3L else {
    # Fall back to store-level version detection
    .zarr_store_version(store)
  }

  if (version == 2L) {
    raw      <- store$read_json(file.path(rel_path, ".zarray"))
    shape    <- if (is.list(raw$shape))  unlist(raw$shape)  else raw$shape
    chunks   <- if (is.list(raw$chunks)) unlist(raw$chunks) else raw$chunks
    di       <- .zarr_parse_dtype(raw$dtype %||% "<f8")
    comp     <- raw$compressor
    fv       <- raw$fill_value
    ord      <- raw$order %||% "C"
    pfx      <- ""
    sep      <- "."
  } else {
    raw      <- store$read_json(file.path(rel_path, "zarr.json"))
    shape    <- unlist(raw$shape)
    chunks   <- unlist(raw$chunk_grid$configuration$chunk_shape)
    codecs   <- .zarr_codecs_as_list(raw$codecs)
    # zarr v3 sharding (zarr-python 3 / anndata >= 0.12 default): the chunk
    # grid describes *shards*; each shard file holds a grid of inner chunks
    # encoded with the inner codec pipeline plus an index of byte ranges.
    sharding <- NULL
    if (length(codecs) && identical(codecs[[1]]$name, "sharding_indexed")) {
      scfg <- codecs[[1]]$configuration
      if (is.data.frame(scfg)) scfg <- as.list(scfg[1, , drop = FALSE])
      inner_codecs <- .zarr_codecs_as_list(scfg$codecs)
      index_codecs <- .zarr_codecs_as_list(scfg$index_codecs)
      sharding <- list(
        chunk_shape    = unlist(scfg$chunk_shape),
        index_location = scfg$index_location %||% "end",
        has_crc32c     = any(vapply(index_codecs, function(cc) identical(cc$name, "crc32c"), logical(1)))
      )
      codecs <- inner_codecs
    }
    di       <- .zarr_parse_dtype_v3(raw$data_type %||% "float64", codecs)
    comp     <- .zarr_extract_compressor_v3(codecs)
    fv       <- raw$fill_value
    ord      <- "C"
    cke      <- raw$chunk_key_encoding
    if (is.data.frame(cke)) cke <- as.list(cke[1, , drop = FALSE])
    if (identical(cke$name %||% "default", "v2")) {
      pfx <- ""
      sep <- cke$configuration$separator %||% "."
    } else {
      pfx <- "c"
      sep <- cke$configuration$separator %||% "/"
    }
  }

  list(
    shape        = shape,
    chunks       = chunks,
    dtype_info   = di,
    compressor   = comp,
    fill_value   = fv,
    order        = ord,
    version      = version,
    chunk_prefix = pfx,
    chunk_sep    = sep,
    is_string    = di$r_type == "character",
    is_bool      = di$r_type == "logical",
    dtype        = if (version == 2L) (raw$dtype %||% "") else NULL,
    sharding     = if (version == 3L) sharding else NULL
  )
}

#' Fetch and decode one (outer) chunk of a zarr array as raw bytes
#'
#' Handles plain chunks and zarr v3 shards. A shard is a single store object
#' holding a C-ordered grid of inner chunks, each encoded with the inner
#' codec pipeline, followed (or preceded) by an index of
#' \code{(offset, nbytes)} uint64 pairs, one per inner chunk, optionally with
#' a crc32c checksum. Missing inner chunks (offset == 2^64 - 1) are filled
#' with the array's fill value. The result is the decoded, decompressed byte
#' buffer of the whole outer chunk in C order, exactly as a non-sharded chunk
#' would decode to.
#'
#' @keywords internal
.zarr_fetch_chunk <- function(store, chunk_key, meta) {
  raw_data <- store$read_bytes(chunk_key)
  if (is.null(meta$sharding)) {
    return(.zarr_decompress(raw_data, meta$compressor))
  }
  if (length(raw_data) == 0L) return(raw_data)
  parts <- .zarr_split_shard(raw_data, meta)
  esz <- meta$dtype_info$size
  outer <- meta$chunks
  inner <- meta$sharding$chunk_shape
  grid <- ceiling(outer / inner)
  fill <- .zarr_fill_bytes(meta)
  n_inner <- prod(grid)
  decoded <- vector("list", n_inner)
  inner_len <- prod(inner)
  for (k in seq_len(n_inner)) {
    blk <- parts[[k]]
    if (is.null(blk)) {
      decoded[[k]] <- rep(fill, inner_len)
    } else {
      blk <- .zarr_decompress(blk, meta$compressor)
      # zarr pads every chunk to full size; guard against short blocks anyway
      if (length(blk) < inner_len * esz) blk <- c(blk, rep(fill, inner_len)[seq_len(inner_len * esz - length(blk))])
      decoded[[k]] <- blk
    }
  }
  if (length(outer) == 1L) {
    out <- do.call(c, decoded)
    return(out[seq_len(outer[1] * esz)])
  }
  if (length(outer) == 2L) {
    out <- rep(fill, prod(outer))[seq_len(prod(outer) * esz)]
    ir <- inner[1]; ic <- inner[2]; oc <- outer[2]
    k <- 0L
    for (ci in seq_len(grid[1]) - 1L) {
      for (cj in seq_len(grid[2]) - 1L) {
        k <- k + 1L
        blk <- decoded[[k]]
        rows <- seq_len(ir) - 1L
        rows <- rows[ci * ir + rows < outer[1]]
        cols_n <- min(ic, oc - cj * ic)
        if (cols_n <= 0L || !length(rows)) next
        seg <- seq_len(cols_n * esz) - 1L
        for (r in rows) {
          dst0 <- ((ci * ir + r) * oc + cj * ic) * esz
          src0 <- (r * ic) * esz
          out[dst0 + seg + 1L] <- blk[src0 + seg + 1L]
        }
      }
    }
    return(out)
  }
  stop("Sharded zarr arrays with more than 2 dimensions are not supported",
       call. = FALSE)
}

#' Fetch and decode one (outer) chunk of a zarr string array
#'
#' @return character vector of length \code{n}
#' @keywords internal
.zarr_fetch_chunk_strings <- function(store, chunk_key, meta, n) {
  raw_data <- store$read_bytes(chunk_key)
  if (length(raw_data) == 0L) return(character(n))
  if (is.null(meta$sharding)) {
    return(.decode_vlen_utf8(.zarr_decompress(raw_data, meta$compressor), n))
  }
  parts <- .zarr_split_shard(raw_data, meta)
  inner_len <- prod(meta$sharding$chunk_shape)
  out <- character(0)
  for (blk in parts) {
    if (is.null(blk)) {
      out <- c(out, character(inner_len))
    } else {
      out <- c(out, .decode_vlen_utf8(.zarr_decompress(blk, meta$compressor), inner_len))
    }
  }
  out[seq_len(n)]
}

#' Split a zarr v3 shard into its inner chunk byte blocks
#'
#' @return list with one raw vector per inner chunk (NULL where missing)
#' @keywords internal
.zarr_split_shard <- function(raw_data, meta) {
  grid <- ceiling(meta$chunks / meta$sharding$chunk_shape)
  n_inner <- prod(grid)
  index_len <- n_inner * 16L + if (isTRUE(meta$sharding$has_crc32c)) 4L else 0L
  total <- length(raw_data)
  if (total < index_len) stop("Corrupt zarr shard: index shorter than expected", call. = FALSE)
  idx_raw <- if (identical(meta$sharding$index_location, "start")) {
    raw_data[seq_len(index_len)]
  } else {
    raw_data[(total - index_len + 1L):total]
  }
  # (offset, nbytes) little-endian uint64 pairs; read as two uint32 halves
  words <- readBin(idx_raw[seq_len(n_inner * 16L)], "integer", n = n_inner * 4L,
                   size = 4L, signed = FALSE, endian = "little")
  lo <- words[seq(1L, length(words), by = 2L)]
  hi <- words[seq(2L, length(words), by = 2L)]
  vals <- lo + hi * 4294967296
  offsets <- vals[seq(1L, length(vals), by = 2L)]
  nbytes  <- vals[seq(2L, length(vals), by = 2L)]
  missing <- (lo[seq(1L, length(lo), by = 2L)] == 4294967295 &
              hi[seq(1L, length(hi), by = 2L)] == 4294967295)
  parts <- vector("list", n_inner)
  for (k in seq_len(n_inner)) {
    if (missing[k] || nbytes[k] == 0) next
    from <- offsets[k] + 1
    to <- offsets[k] + nbytes[k]
    if (to > total) stop("Corrupt zarr shard: inner chunk exceeds shard size", call. = FALSE)
    parts[[k]] <- raw_data[from:to]
  }
  parts
}

#' Byte pattern of the fill value for one element of a zarr array
#'
#' @keywords internal
.zarr_fill_bytes <- function(meta) {
  di <- meta$dtype_info
  fv <- meta$fill_value %||% 0
  if (di$r_type == "character") return(as.raw(0))
  v <- .raw_fill_to_r(fv, di)
  if (di$r_type == "double") {
    writeBin(as.double(v), raw(), size = di$size, endian = di$endian)
  } else if (di$r_type == "logical") {
    as.raw(as.integer(isTRUE(v)))
  } else {
    writeBin(as.integer(v), raw(), size = di$size, endian = di$endian)
  }
}

#' Read and parse a JSON file
#'
#' @param path Path to JSON file
#'
#' @return Parsed list
#'
#' @keywords internal
#'
.zarr_read_json <- function(path) {
  if (!file.exists(path)) return(list())
  jsonlite::fromJSON(path, simplifyVector = TRUE)
}

#' Read zarr node attributes
#'
#' Reads .zattrs (v2) or zarr.json attributes field (v3).
#'
#' @param store_path Path to zarr store
#' @param rel_path Relative path within store (empty string for root)
#'
#' @return Named list of attributes
#'
#' @keywords internal
#'
.zarr_read_attrs <- function(store_path, rel_path = "") {
  store <- .zarr_make_store(store_path)
  version <- .zarr_store_version(store)
  inner <- function(name) {
    if (nzchar(rel_path)) file.path(rel_path, name) else name
  }
  if (version == 2L) {
    store$read_json(inner(".zattrs"))
  } else {
    meta <- store$read_json(inner("zarr.json"))
    meta$attributes %||% list()
  }
}

#' Determine zarr node type
#'
#' @param store_path Path to zarr store
#' @param rel_path Relative path within store
#'
#' @return "group", "array", or "missing"
#'
#' @keywords internal
#'
.zarr_node_type <- function(store_path, rel_path) {
  store <- .zarr_make_store(store_path)
  if (!store$exists(rel_path)) return("missing")

  version <- .zarr_store_version(store)
  inner <- function(name) {
    if (nzchar(rel_path)) file.path(rel_path, name) else name
  }
  if (version == 2L) {
    if (store$exists(inner(".zarray"))) return("array")
    if (store$exists(inner(".zgroup"))) return("group")
    return("missing")
  }
  # v3
  if (!store$exists(inner("zarr.json"))) return("missing")
  meta <- store$read_json(inner("zarr.json"))
  meta$node_type %||% "missing"
}

#' List children of a zarr group
#'
#' @param store_path Path to zarr store
#' @param rel_path Relative path to group within store
#'
#' @return Character vector of child names
#'
#' @keywords internal
#'
.zarr_list_children <- function(store_path, rel_path = "") {
  store <- .zarr_make_store(store_path)
  store$list_dirs(rel_path)
}

#' Is the package's built-in libzstd bridge available?
#'
#' TRUE when scConvert was compiled against libzstd (see \code{configure}).
#'
#' @keywords internal
.zstd_internal_available <- function() {
  isTRUE(tryCatch(.Call(C_zstd_available), error = function(e) FALSE))
}

#' Decompress chunk data
#'
#' @param raw_data Raw vector of compressed data
#' @param compressor Compressor specification list from .zarray metadata
#'
#' @return Decompressed raw vector
#'
#' @keywords internal
#'
.zarr_decompress <- function(raw_data, compressor) {
  if (is.null(compressor)) return(raw_data)
  comp_id <- compressor$id
  if (comp_id %in% c("zlib", "gzip")) {
    memDecompress(raw_data, type = "gzip")
  } else if (comp_id == "zstd") {
    if (.zstd_internal_available()) {
      return(.Call(C_zstd_decompress, raw_data))
    }
    if (!requireNamespace("zstdlite", quietly = TRUE)) {
      stop("Reading zstd-compressed zarr data requires a Zstd codec ",
           "package. No suitable provider was found on the search path. ",
           "zstdlite is currently the supported provider; see ",
           "https://github.com/coolbutuseless/zstdlite for installation.",
           call. = FALSE)
    }
    zstdlite::zstd_decompress(raw_data)
  } else if (comp_id == "blosc") {
    if (!requireNamespace("blosc", quietly = TRUE)) {
      stop("blosc package required for blosc-compressed zarr data. ",
           "Install with: install.packages('blosc')", call. = FALSE)
    }
    blosc::blosc_decompress(raw_data)
  } else {
    stop("Unsupported zarr compressor: ", comp_id,
         ". Supported: zlib, gzip, zstd, blosc.", call. = FALSE)
  }
}

#' Compress chunk data
#'
#' @param raw_data Raw vector to compress
#' @param compressor Compressor specification list
#'
#' @return Compressed raw vector
#'
#' @keywords internal
#'
.zarr_compress <- function(raw_data, compressor) {
  if (is.null(compressor)) return(raw_data)
  comp_id <- compressor$id
  if (comp_id %in% c("zlib", "gzip")) {
    memCompress(raw_data, type = "gzip")
  } else if (comp_id == "zstd") {
    level <- compressor$level %||% 3L
    if (.zstd_internal_available()) {
      return(.Call(C_zstd_compress, raw_data, as.integer(level)))
    }
    if (!requireNamespace("zstdlite", quietly = TRUE)) {
      stop("Writing zstd-compressed zarr data requires a Zstd codec ",
           "package; none was found on the search path. ",
           "See https://github.com/coolbutuseless/zstdlite. ",
           "Use compressor = 'zlib' to fall back to gzip.", call. = FALSE)
    }
    level <- compressor$level %||% 3L
    zstdlite::zstd_compress(raw_data, level = as.integer(level))
  } else if (comp_id == "blosc") {
    if (!requireNamespace("blosc", quietly = TRUE)) {
      stop("blosc package required for blosc compression", call. = FALSE)
    }
    blosc::blosc_compress(raw_data)
  } else {
    stop("Unsupported compressor: ", comp_id, call. = FALSE)
  }
}

#' Resolve a writer-side compressor spec to a zarr-codec list
#'
#' Accepts a user-supplied compressor argument and returns a list
#' \code{list(id, level, ...)} suitable for \code{.zarr_compress()} and for
#' writing into a \code{.zarray} \code{compressor} field. \code{NULL} means
#' "auto": Zstd when a Zstd codec package (currently \pkg{zstdlite}) is on
#' the search path; otherwise zlib at the current package compression level.
#' As of 2026 there is no maintained CRAN Zstd-bytes wrapper, so the auto
#' path almost always lands on zlib; the resolver still picks Zstd if the
#' user has installed a provider out of band.
#'
#' @param x One of \code{NULL}, a string (\code{"zstd"}, \code{"gzip"},
#'   \code{"zlib"}, \code{"blosc"}, \code{"none"}), or a list with at least
#'   an \code{id} field.
#' @param level Override the codec level. When \code{NULL}, a per-codec
#'   default is used.
#'
#' @return Either \code{NULL} (no compression) or a list with \code{id} and
#'   typically \code{level}.
#'
#' @keywords internal
#'
.zarr_resolve_compressor <- function(x = NULL, level = NULL) {
  if (is.list(x) && !is.null(x$id)) return(x)
  if (identical(x, "none") || identical(x, FALSE)) return(NULL)
  if (is.null(x) || identical(x, "auto")) {
    if (.zstd_internal_available() || requireNamespace("zstdlite", quietly = TRUE)) {
      return(list(id = "zstd", level = as.integer(level %||% 3L)))
    }
    return(list(id = "zlib", level = as.integer(level %||% GetCompressionLevel())))
  }
  id <- tolower(as.character(x))
  if (id == "gzip") id <- "zlib"
  switch(id,
    zlib  = list(id = "zlib",  level = as.integer(level %||% GetCompressionLevel())),
    zstd  = list(id = "zstd",  level = as.integer(level %||% 3L)),
    blosc = list(id = "blosc", level = as.integer(level %||% 5L)),
    stop("Unsupported zarr compressor: ", id,
         ". Supported: zstd, zlib (gzip), blosc, none.", call. = FALSE)
  )
}

#' Parse zarr v2 dtype string to R type info
#'
#' @param dtype Zarr dtype string (e.g., "<f8", "<i4", "|O")
#'
#' @return List with r_type, size, endian, is_object
#'
#' @keywords internal
#'
.zarr_parse_dtype <- function(dtype) {
  endian <- "little"
  if (grepl("^>", dtype)) endian <- "big"
  dtype_clean <- gsub("^[<>|=]", "", dtype)

  type_char <- substr(dtype_clean, 1, 1)
  size_str <- gsub("[^0-9]", "", dtype_clean)
  size <- if (nchar(size_str) > 0) as.integer(size_str) else 1L

  list(
    r_type = switch(type_char,
      "f" = "double",
      "i" = "integer",
      "u" = "integer",
      "b" = "logical",
      "O" = "character",
      "S" = "character",
      "U" = "character",
      "double"
    ),
    size = size,
    endian = endian,
    signed = type_char != "u",
    is_object = dtype_clean == "O"
  )
}

#' Convert zarr fill_value to R scalar of the right type
#' @keywords internal
.raw_fill_to_r <- function(fill_value, dtype_info) {
  if (dtype_info$r_type == "logical") return(as.logical(fill_value %||% FALSE))
  if (dtype_info$r_type == "integer") return(as.integer(fill_value %||% 0L))
  as.double(fill_value %||% 0)
}

#' Read a zarr numeric array from disk (v2 and v3)
#'
#' @param store_path Path to zarr store
#' @param rel_path Relative path to array within store
#' @param slice Optional named list of per-dimension index vectors:
#'   \code{list(d1 = 1L:1000L)} (1D), \code{list(d1 = ..., d2 = ...)}
#'   (2D). \code{NULL} on a dim means "all". When supplied, only the
#'   chunks that intersect the requested indices are fetched.
#'
#' @return Numeric vector or matrix
#'
#' @keywords internal
#'
.zarr_read_numeric <- function(store_path, rel_path, slice = NULL) {
  store      <- .zarr_make_store(store_path)
  meta       <- .zarr_read_array_meta(store, rel_path)
  dtype_info <- meta$dtype_info
  shape      <- meta$shape
  chunks     <- meta$chunks
  compressor <- meta$compressor
  order      <- meta$order
  n_elements <- prod(shape)
  ndim       <- length(shape)

  if (!is.null(slice)) {
    return(.zarr_read_numeric_sliced(store, rel_path, meta, dtype_info,
                                     shape, chunks, compressor, slice))
  }

  n_chunks_per_dim <- ceiling(shape / chunks)
  total_chunks     <- prod(n_chunks_per_dim)

  if (total_chunks == 1L) {
    chunk_key <- .zarr_chunk_path(rel_path, rep(0L, ndim),
                                  meta$chunk_prefix, meta$chunk_sep)
    if (!store$exists(chunk_key)) {
      fv <- meta$fill_value %||% 0
      return(rep(.raw_fill_to_r(fv, dtype_info), n_elements))
    }
    raw_data <- .zarr_fetch_chunk(store, chunk_key, meta)
    values   <- .raw_to_r_type(raw_data, dtype_info, prod(chunks))
    values   <- values[seq_len(n_elements)]
  } else {
    values <- .zarr_read_chunked(store, rel_path, meta, dtype_info, shape,
                                 chunks, n_chunks_per_dim, compressor)
  }

  if (ndim == 1L) return(values)
  if (ndim == 2L) {
    return(matrix(values, nrow = shape[1], ncol = shape[2],
                  byrow = (order == "C")))
  }
  values
}

#' Chunk-selective read of a 1D or 2D zarr v2 numeric array
#'
#' @param slice Named list with \code{d1}, optionally \code{d2}: each
#'   either \code{NULL} (full dim) or an integer vector of 1-based
#'   indices into that dim.
#'
#' @keywords internal
.zarr_read_numeric_sliced <- function(store, rel_path, meta, dtype_info,
                                       shape, chunks, compressor, slice) {
  ndim <- length(shape)
  order <- meta$order %||% "C"
  resolve <- function(idx, dim_size) {
    if (is.null(idx)) return(seq_len(dim_size))
    if (is.logical(idx)) idx <- which(idx)
    idx <- as.integer(idx)
    if (any(idx < 1L | idx > dim_size)) {
      stop("slice index out of range for dim of size ", dim_size,
           call. = FALSE)
    }
    idx
  }

  if (ndim == 1L) {
    idx <- resolve(slice$d1, shape[1])
    chunk_size <- chunks[1]
    out <- numeric(length(idx))
    chunk_ids <- unique((idx - 1L) %/% chunk_size)
    for (cid in chunk_ids) {
      chunk_key <- .zarr_chunk_path(rel_path, cid, meta$chunk_prefix, meta$chunk_sep)
      if (!store$exists(chunk_key)) next
      raw <- .zarr_fetch_chunk(store, chunk_key, meta)
      chunk_vals <- .raw_to_r_type(raw, dtype_info, chunk_size)
      lo <- cid * chunk_size + 1L
      hi <- lo + chunk_size - 1L
      in_chunk <- idx >= lo & idx <= hi
      within_pos <- idx[in_chunk] - lo + 1L
      out[in_chunk] <- chunk_vals[within_pos]
    }
    return(out)
  }

  if (ndim == 2L) {
    row_idx <- resolve(slice$d1, shape[1])
    col_idx <- resolve(slice$d2, shape[2])
    cr <- chunks[1]; cc <- chunks[2]
    out <- matrix(0, nrow = length(row_idx), ncol = length(col_idx))
    row_chunk_ids <- unique((row_idx - 1L) %/% cr)
    col_chunk_ids <- unique((col_idx - 1L) %/% cc)
    for (rci in row_chunk_ids) {
      r_lo <- rci * cr + 1L; r_hi <- r_lo + cr - 1L
      rows_in_chunk <- row_idx >= r_lo & row_idx <= r_hi
      r_within <- row_idx[rows_in_chunk] - r_lo + 1L
      out_r_pos <- which(rows_in_chunk)
      for (cci in col_chunk_ids) {
        chunk_key <- .zarr_chunk_path(rel_path, c(rci, cci), meta$chunk_prefix, meta$chunk_sep)
        if (!store$exists(chunk_key)) next
        raw <- .zarr_fetch_chunk(store, chunk_key, meta)
        chunk_size <- cr * cc
        chunk_vals <- .raw_to_r_type(raw, dtype_info, chunk_size)
        chunk_mat <- matrix(chunk_vals, nrow = cr, ncol = cc,
                            byrow = (order == "C"))
        c_lo <- cci * cc + 1L; c_hi <- c_lo + cc - 1L
        cols_in_chunk <- col_idx >= c_lo & col_idx <= c_hi
        c_within <- col_idx[cols_in_chunk] - c_lo + 1L
        out_c_pos <- which(cols_in_chunk)
        out[out_r_pos, out_c_pos] <- chunk_mat[r_within, c_within, drop = FALSE]
      }
    }
    return(out)
  }
  stop("Sliced read for >2D arrays not supported", call. = FALSE)
}

#' Build chunk file path (zarr v2 and v3)
#'
#' @param array_dir Array directory path (empty string for store root)
#' @param chunk_coords Integer vector of chunk coordinates (0-based)
#' @param chunk_prefix Prefix prepended before coordinates ("" for v2, "c" for v3)
#' @param chunk_sep Separator between dimension coordinates ("." for v2, "/" for v3)
#'
#' @keywords internal
.zarr_chunk_path <- function(array_dir, chunk_coords,
                              chunk_prefix = "", chunk_sep = ".") {
  key_coords <- paste(chunk_coords, collapse = chunk_sep)
  key <- if (nzchar(chunk_prefix)) file.path(chunk_prefix, key_coords) else key_coords
  if (nzchar(array_dir)) file.path(array_dir, key) else key
}

#' Read multi-chunk zarr v2 numeric array
#'
#' @keywords internal
#'
.zarr_read_chunked <- function(store_or_path, array_rel, meta, dtype_info,
                                shape, chunks, n_chunks_per_dim, compressor) {
  store <- .zarr_make_store(store_or_path)
  ndim <- length(shape)
  n_elements <- prod(shape)

  if (ndim == 1) {
    values <- numeric(n_elements)
    for (ci in seq_len(n_chunks_per_dim) - 1L) {
      chunk_key <- .zarr_chunk_path(array_rel, ci, meta$chunk_prefix, meta$chunk_sep)
      if (!store$exists(chunk_key)) next
      raw_data <- .zarr_fetch_chunk(store, chunk_key, meta)
      chunk_vals <- .raw_to_r_type(raw_data, dtype_info, chunks)
      start_idx <- ci * chunks + 1L
      end_idx <- min(start_idx + chunks - 1L, n_elements)
      n_copy <- end_idx - start_idx + 1L
      values[start_idx:end_idx] <- chunk_vals[seq_len(n_copy)]
    }
    return(values)
  }

  if (ndim == 2) {
    order <- meta$order %||% "C"
    # For 2D, iterate through chunk grid in C order
    values <- numeric(n_elements)
    for (ci in seq_len(n_chunks_per_dim[1]) - 1L) {
      for (cj in seq_len(n_chunks_per_dim[2]) - 1L) {
        chunk_key <- .zarr_chunk_path(array_rel, c(ci, cj), meta$chunk_prefix, meta$chunk_sep)
        if (!store$exists(chunk_key)) next
        raw_data <- .zarr_fetch_chunk(store, chunk_key, meta)
        chunk_size <- prod(chunks)
        chunk_vals <- .raw_to_r_type(raw_data, dtype_info, chunk_size)

        # Copy chunk data into the correct position in the flat array
        row_start <- ci * chunks[1]
        col_start <- cj * chunks[2]
        row_end <- min(row_start + chunks[1] - 1L, shape[1] - 1L)
        col_end <- min(col_start + chunks[2] - 1L, shape[2] - 1L)

        if (order == "C") {
          # C order: row-major in chunk, row-major in output
          chunk_mat <- matrix(chunk_vals, nrow = chunks[1], ncol = chunks[2],
                              byrow = TRUE)
          for (r in row_start:row_end) {
            for (cc in col_start:col_end) {
              flat_idx <- r * shape[2] + cc + 1L
              values[flat_idx] <- chunk_mat[r - row_start + 1L, cc - col_start + 1L]
            }
          }
        } else {
          # F order: column-major
          chunk_mat <- matrix(chunk_vals, nrow = chunks[1], ncol = chunks[2])
          for (cc in col_start:col_end) {
            for (r in row_start:row_end) {
              flat_idx <- cc * shape[1] + r + 1L
              values[flat_idx] <- chunk_mat[r - row_start + 1L, cc - col_start + 1L]
            }
          }
        }
      }
    }
    return(values)
  }

  stop("Arrays with > 2 dimensions not supported", call. = FALSE)
}

#' Convert raw bytes to R type
#'
#' @keywords internal
#'
.raw_to_r_type <- function(raw_data, dtype_info, n) {
  if (dtype_info$r_type == "double") {
    readBin(raw_data, "double", n = n, size = dtype_info$size,
            endian = dtype_info$endian)
  } else if (dtype_info$r_type == "integer") {
    readBin(raw_data, "integer", n = n, size = dtype_info$size,
            signed = dtype_info$signed, endian = dtype_info$endian)
  } else if (dtype_info$r_type == "logical") {
    as.logical(readBin(raw_data, "integer", n = n, size = 1L))
  } else {
    stop("Unsupported zarr dtype for numeric reading", call. = FALSE)
  }
}

#' Read a vlen-utf8 encoded string array from zarr v2 store
#'
#' AnnData zarr stores encode string arrays using the vlen-utf8 filter.
#' Each string in the chunk is stored as a 4-byte little-endian int32
#' length prefix followed by that many bytes of UTF-8 text.
#'
#' @param store_path Path to zarr store
#' @param rel_path Relative path to string array within store
#'
#' @return Character vector
#'
#' @keywords internal
#'
.zarr_read_strings <- function(store_path, rel_path, slice_idx = NULL) {
  store <- .zarr_make_store(store_path)

  # Read array metadata
  meta       <- .zarr_read_array_meta(store, rel_path)
  shape      <- meta$shape
  total_n    <- prod(shape)
  chunks     <- meta$chunks
  compressor <- meta$compressor
  chunk_size <- chunks[1]

  if (!is.null(slice_idx)) {
    if (is.logical(slice_idx)) slice_idx <- which(slice_idx)
    slice_idx <- as.integer(slice_idx)
    if (any(slice_idx < 1L | slice_idx > total_n)) {
      stop("string-array slice index out of range (1..", total_n, ")",
           call. = FALSE)
    }
    out <- character(length(slice_idx))
    chunk_ids <- unique((slice_idx - 1L) %/% chunk_size)
    for (cid in chunk_ids) {
      chunk_key <- .zarr_chunk_path(rel_path, cid, meta$chunk_prefix, meta$chunk_sep)
      lo <- cid * chunk_size + 1L
      hi <- min(lo + chunk_size - 1L, total_n)
      n_in_chunk <- hi - lo + 1L
      in_slice <- slice_idx >= lo & slice_idx <= hi
      out_pos <- which(in_slice)
      within <- slice_idx[in_slice] - lo + 1L
      if (!store$exists(chunk_key)) {
        out[out_pos] <- ""
        next
      }
      chunk_strings <- .zarr_fetch_chunk_strings(store, chunk_key, meta, n_in_chunk)
      out[out_pos] <- chunk_strings[within]
    }
    return(out)
  }

  n_chunks <- ceiling(total_n / chunk_size)
  all_strings <- character(0)

  for (chunk_idx in seq_len(n_chunks) - 1L) {
    chunk_key <- .zarr_chunk_path(rel_path, chunk_idx, meta$chunk_prefix, meta$chunk_sep)
    if (!store$exists(chunk_key)) {
      # Fill with empty strings for missing chunks
      all_strings <- c(all_strings,
                       rep("", min(chunk_size, total_n - length(all_strings))))
      next
    }
    n_in_chunk <- min(chunk_size, total_n - length(all_strings))
    strings <- .zarr_fetch_chunk_strings(store, chunk_key, meta, n_in_chunk)
    all_strings <- c(all_strings, strings)
  }

  all_strings[seq_len(total_n)]
}

#' Decode vlen-utf8 encoded raw data to character vector
#'
#' @param raw_data Raw vector containing vlen-utf8 encoded strings
#' @param n Number of strings to decode
#'
#' @return Character vector of length n
#'
#' @keywords internal
#'
.decode_vlen_utf8 <- function(raw_data, n) {
  con <- rawConnection(raw_data, "r")
  on.exit(close(con))
  # numcodecs VLenUTF8 format starts with a 4-byte item count header.
  # Read the first int32: if it equals n, it's the header; otherwise
  # it's the length of the first string (legacy format without header).
  first_int <- readBin(con, "integer", n = 1L, size = 4L, endian = "little")
  if (length(first_int) == 0 || is.na(first_int)) return(character(n))
  strings <- character(n)
  if (first_int == n) {
    # Standard numcodecs format: first_int is the item count header
    for (i in seq_len(n)) {
      len <- readBin(con, "integer", n = 1L, size = 4L, endian = "little")
      if (length(len) == 0 || is.na(len)) break
      if (len < 0) {
        strings[i] <- NA_character_
      } else if (len == 0) {
        strings[i] <- ""
      } else {
        str_bytes <- readBin(con, "raw", n = len)
        strings[i] <- rawToChar(str_bytes)
      }
    }
  } else {
    # Legacy format without header: first_int is the first string length
    if (first_int < 0) {
      strings[1] <- NA_character_
    } else if (first_int == 0) {
      strings[1] <- ""
    } else {
      str_bytes <- readBin(con, "raw", n = first_int)
      strings[1] <- rawToChar(str_bytes)
    }
    for (i in seq_len(n - 1L) + 1L) {
      len <- readBin(con, "integer", n = 1L, size = 4L, endian = "little")
      if (length(len) == 0 || is.na(len)) break
      if (len < 0) {
        strings[i] <- NA_character_
      } else if (len == 0) {
        strings[i] <- ""
      } else {
        str_bytes <- readBin(con, "raw", n = len)
        strings[i] <- rawToChar(str_bytes)
      }
    }
  }
  strings
}

#' Encode character vector to vlen-utf8 raw data
#'
#' @param strings Character vector to encode
#'
#' @return Raw vector in vlen-utf8 format
#'
#' @keywords internal
#'
.encode_vlen_utf8 <- function(strings) {
  n <- length(strings)
  is_na <- is.na(strings)
  strings[is_na] <- ""
  # Vectorized: convert all strings to raw bytes at once
  byte_list <- lapply(strings, charToRaw)
  lens <- vapply(byte_list, length, integer(1L))
  lens[is_na] <- 0L
  # Pre-allocate: 4 (header) + n*4 (length prefixes) + sum(lens) (string bytes)
  total_size <- 4L + n * 4L + sum(lens)
  buf <- raw(total_size)
  # Write item count header
  buf[1:4] <- writeBin(n, raw(), size = 4L, endian = "little")
  # Pre-compute all length prefixes as raw
  len_raw <- writeBin(lens, raw(), size = 4L, endian = "little")
  # Interleave: [len1][bytes1][len2][bytes2]...
  pos <- 5L
  for (i in seq_len(n)) {
    buf[pos:(pos + 3L)] <- len_raw[((i - 1L) * 4L + 1L):(i * 4L)]
    pos <- pos + 4L
    if (lens[i] > 0L) {
      end_pos <- pos + lens[i] - 1L
      buf[pos:end_pos] <- byte_list[[i]]
      pos <- end_pos + 1L
    }
  }
  buf
}

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# Zarr v2 Write Helpers
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#' Create a zarr v2 group directory with metadata
#'
#' @param dir Directory path for the group
#' @param attrs Named list of attributes (written to .zattrs)
#'
#' @keywords internal
#'
.zarr_create_group <- function(dir, attrs = NULL) {
  dir.create(dir, recursive = TRUE, showWarnings = FALSE)
  writeLines('{"zarr_format":2}', file.path(dir, ".zgroup"))
  if (!is.null(attrs) && length(attrs) > 0) {
    .zarr_write_attrs(dir, attrs)
  }
}

#' Write zarr attributes to .zattrs file
#'
#' @param dir Directory containing the zarr node
#' @param attrs Named list of attributes
#'
#' @keywords internal
#'
.zarr_write_attrs <- function(dir, attrs) {
  json <- jsonlite::toJSON(attrs, auto_unbox = TRUE, null = "null", pretty = TRUE)
  writeLines(json, file.path(dir, ".zattrs"))
}

#' Write a zarr v2 numeric array
#'
#' @param dir Directory for the array
#' @param data Numeric vector or matrix
#' @param dtype Zarr dtype string (default "<f8" for float64)
#' @param compressor Compressor spec list (default gzip level 4)
#' @param attrs Optional attributes for .zattrs
#'
#' @keywords internal
#'
.zarr_write_numeric <- function(dir, data, dtype = NULL, compressor = NULL,
                                 attrs = NULL) {
  dir.create(dir, recursive = TRUE, showWarnings = FALSE)

  # Determine dtype from data
  if (is.null(dtype)) {
    dtype <- if (is.integer(data)) "<i4" else "<f8"
  }

  # Default compressor
  if (is.null(compressor)) {
    compressor <- list(id = "zlib", level = 4L)
  }

  # Determine shape and flatten data
  if (is.matrix(data)) {
    shape <- dim(data)
    # Convert to C order (row-major) from R's column-major
    flat_data <- as.vector(t(data))
    order <- "C"
  } else {
    shape <- length(data)
    flat_data <- data
    order <- "C"
  }
  # Single chunk per array — our zarr writer only writes one chunk file.
  # Multi-chunk would require writing separate chunk files (0, 1, 2, ...).
  chunks <- shape

  # Write .zarray metadata
  meta <- list(
    zarr_format = 2L,
    shape = as.list(as.integer(shape)),
    chunks = as.list(as.integer(chunks)),
    dtype = dtype,
    compressor = compressor,
    fill_value = if (grepl("b", dtype)) FALSE else if (grepl("f", dtype)) 0.0 else 0L,
    order = order,
    filters = NULL
  )
  json <- jsonlite::toJSON(meta, auto_unbox = TRUE, null = "null", pretty = TRUE)
  writeLines(json, file.path(dir, ".zarray"))

  # Write attributes
  if (!is.null(attrs) && length(attrs) > 0) {
    .zarr_write_attrs(dir, attrs)
  }

  # Convert data to raw bytes
  dtype_info <- .zarr_parse_dtype(dtype)
  if (dtype_info$r_type == "double") {
    raw_data <- writeBin(as.double(flat_data), raw(), size = dtype_info$size,
                         endian = "little")
  } else if (dtype_info$r_type == "integer") {
    raw_data <- writeBin(as.integer(flat_data), raw(), size = dtype_info$size,
                         endian = "little")
  } else if (dtype_info$r_type == "logical") {
    # Boolean: write as single-byte integers (0/1)
    raw_data <- as.raw(as.integer(flat_data))
  } else {
    stop("Unsupported dtype for writing: ", dtype, call. = FALSE)
  }

  # Compress
  raw_data <- .zarr_compress(raw_data, compressor)

  # Write chunk
  chunk_name <- if (length(shape) == 2) "0.0" else "0"
  writeBin(raw_data, file.path(dir, chunk_name))
}

#' Write a zarr v2 vlen-utf8 string array
#'
#' @param dir Directory for the array
#' @param strings Character vector
#' @param compressor Compressor spec list (default gzip level 4)
#' @param attrs Optional attributes for .zattrs
#'
#' @keywords internal
#'
.zarr_write_strings <- function(dir, strings, compressor = NULL, attrs = NULL) {
  dir.create(dir, recursive = TRUE, showWarnings = FALSE)

  if (is.null(compressor)) {
    compressor <- list(id = "zlib", level = 4L)
  }

  n <- length(strings)

  # Write .zarray metadata
  meta <- list(
    zarr_format = 2L,
    shape = list(as.integer(n)),
    chunks = list(as.integer(n)),
    dtype = "|O",
    compressor = compressor,
    fill_value = 0L,
    order = "C",
    filters = list(list(id = "vlen-utf8"))
  )
  json <- jsonlite::toJSON(meta, auto_unbox = TRUE, null = "null", pretty = TRUE)
  writeLines(json, file.path(dir, ".zarray"))

  if (!is.null(attrs) && length(attrs) > 0) {
    .zarr_write_attrs(dir, attrs)
  }

  # Encode strings as vlen-utf8
  raw_data <- .encode_vlen_utf8(strings)

  # Compress
  raw_data <- .zarr_compress(raw_data, compressor)

  # Write chunk
  writeBin(raw_data, file.path(dir, "0"))
}
